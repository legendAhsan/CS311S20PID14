﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace activity
{
    public partial class Form5 : Form
    {
        public Form5()
        {
            InitializeComponent();

        }
        string labeltext = "\n\n\n1. You can add maximum of 12 classes and maximum of 12 courses in each class.\n "+
                               "2. You have to first add the class and then assign courses and teacher detail by simply clicking on class name\nBy default details will be added to first class shown in the list.\n"+
                               "3. You can see the courses and teacher of each class by pressing show details button.\n"+
                               "4. After adding the details you have to press on generate button which will ask to select which algorithm you\n want and then press go button " +
                               "   time table will be generated.\n" +
                               "5. You can see the time table by pressing on view time table button\n\n NOTE: In the consecutive or not 0 means non-consecutive and 1 means Consecutive lectures. .";

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void Form5_Load(object sender, EventArgs e)
        {
            label1.Text = labeltext;
        }
    }
}
