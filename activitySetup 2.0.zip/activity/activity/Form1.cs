﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace activity
{
    public partial class Form1 : Form
    {
        private Form currentchildform;
        public Form1()
        {
            InitializeComponent();
            if (classescounter == 0)
            {
                dataGridView2.Visible = false;
                button1.Enabled = false;
                show_detail.Enabled = false;
            }
        }
        public static string[][,] cd1 = new string[12][,] {
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5]
         };

        public static int[] classCourse = new int[12] { 0, 0, 0, 0, 0,0,0,0,0,0,0,0 };
        string[] classes = new string[12];
        public static string[,] aa;
        public static int[] asd = { 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0 };
        public static int classescounter = 0;
         public static int classIndex = 0;
        
        private void button1_Click(object sender, EventArgs e)
        {
            int teacherNameLength=textBox1.Text.Length;
            int subjectNameLength = textBox3.Text.Length;
            if(teacherNameLength<50 && subjectNameLength < 50)
            {
                int tid;
                bool parsesuccess = int.TryParse(textBox2.Text, out tid);
                if (textBox1.Text != null && textBox3.Text != null)
                {
                    if (parsesuccess)
                    {
                        if (Convert.ToInt32(textBox2.Text) >= 0 && Convert.ToInt32(textBox2.Text) < 50)
                        {
                            bool teacherNumberCheck = false;
                            for (int i = 0; i < classescounter; i++)
                            {
                                for (int j = 0; j < classCourse[i]; j++)
                                {
                                    if (textBox2.Text == cd1[i][j, 1])
                                    {
                                        teacherNumberCheck = true;
                                        break;
                                    }
                                }
                            }
                            int totalClassWorkingHour = 0;
                            for (int j = 0; j < classCourse[classIndex]; j++)
                            {

                                totalClassWorkingHour += Convert.ToInt32(cd1[classIndex][j, 3]);
                                break;

                            }

                            if (teacherNumberCheck)
                            {
                                MessageBox.Show("This teacher id already exist or\nlimit of teachers reached");
                            }
                            else
                            {
                                if (totalClassWorkingHour < 31 && classCourse[classIndex] < 10)
                                {
                                    cd1[classIndex][classCourse[classIndex], 0] = textBox1.Text;
                                    cd1[classIndex][classCourse[classIndex], 1] = textBox2.Text;
                                    cd1[classIndex][classCourse[classIndex], 2] = textBox3.Text;
                                    cd1[classIndex][classCourse[classIndex], 3] = textBox4.Text;
                                    cd1[classIndex][classCourse[classIndex], 4] = textBox5.Text;
                                    classCourse[classIndex] = classCourse[classIndex] + 1;
                                    MessageBox.Show("Details have been added successfully");
                                    textBox1.Clear();
                                    textBox2.Clear();
                                    textBox3.Clear();
                                    textBox4.Text = "Select";
                                    textBox5.Text = "Select";
                                }
                                else
                                {
                                    MessageBox.Show("Working Hour limit(30) has been reached for this class or\nClass course limit(10) has been reached.");
                                }

                            }

                        }
                        else
                        {
                            MessageBox.Show("Teacher Id must be between 0 to 49");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Teacher id must be in digits");
                    }
                }
                else
                {
                    MessageBox.Show("Teacher and subject name must be string");
                }
            }
            else
            {
                MessageBox.Show("Teacher name or subject name length\ncannot be greater than 50");
            }
           
        }

        
        public void populate(string[] classes)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Classes".ToString());
            
            for (int i = 0; i < classescounter;i++){
                DataRow dr = table.NewRow();
                dr["Classes"] = classes[i];                        
                table.Rows.Add(dr);
            }
            
            var bindingSource = new BindingSource();
            bindingSource.DataSource = table;
            dataGridView2.DataSource = bindingSource;
            bindingSource.ResetBindings(true);


        }

        

        


        private void show_detail_Click(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.TopLevel = false;
            f2.FormBorderStyle = FormBorderStyle.None;
            f2.Dock = DockStyle.Fill;
            panel4.Controls.Add(f2);
            panel4.Tag = f2;
            f2.BringToFront();
            
            f2.Show();
            currentchildform = f2;
           // populate(input_detail);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
       
        private void button3_Click(object sender, EventArgs e)
        {
            
            string classcheck= textBox6.Text;
            int classNameLength = textBox6.Text.Length;
            if (classescounter < 12)
            {
                if (classcheck != "" && classNameLength<50)
                {
                    classes[classescounter] = classcheck;
                    classescounter++;
                    dataGridView2.Visible = true;
                    button1.Enabled = true;
                    show_detail.Enabled = true;
                    populate(classes);
                }
                else
                {
                    MessageBox.Show("you have not added any class name");
                }
            }
            else
            {
                MessageBox.Show("You can add maximum 12 Classes");
            }
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form4 f4 = new Form4();
            f4.TopLevel = false;
            f4.FormBorderStyle = FormBorderStyle.None;
            f4.Dock = DockStyle.Fill;
            panel4.Controls.Add(f4);
            panel4.Tag = f4;
            f4.BringToFront();

            f4.Show();
            currentchildform = f4;
            // aa = Time_Table_Generator(cd1, asd,classescounter,classCourse);
            // aa = Minimum_Room_Allocator(aa);
            // populatetable(aa);

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form3 f3 = new Form3();
            f3.TopLevel = false;
            f3.FormBorderStyle = FormBorderStyle.None;
            f3.Dock = DockStyle.Fill;
            panel4.Controls.Add(f3);
            panel4.Tag = f3;
            f3.BringToFront();
            f3.Show();
            currentchildform = f3;
           // populatetable(aa);
        }

        private bool checkOpened(string name)
        {
            FormCollection fc = Application.OpenForms;
            foreach(Form frm in fc)
            {
                if (frm.Text == name)
                {
                    return true;
                }
            }
            return false;
        }

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            classIndex = e.RowIndex;
            if (currentchildform != null)
            {
                currentchildform.Close();
            }
         
           
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (currentchildform != null)
            {
                currentchildform.Close();
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 f5 = new Form5();
            f5.TopLevel = false;
            f5.FormBorderStyle = FormBorderStyle.None;
            f5.Dock = DockStyle.Fill;
            panel4.Controls.Add(f5);
            panel4.Tag = f5;
            f5.BringToFront();
            f5.Show();
            currentchildform = f5;
        }

        private void textBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "1")
            {
                textBox4.Items.Clear();
                for(int i = 1; i <= 3;i++)
                {
                    textBox4.Items.Add(Convert.ToString(i));
                }
            }
            if (textBox5.Text == "0")
            {
                textBox4.Items.Clear();
                for (int i = 1; i <= 10;i++)
                {
                    textBox4.Items.Add(Convert.ToString(i));
                }
            }
        }
    }
}
