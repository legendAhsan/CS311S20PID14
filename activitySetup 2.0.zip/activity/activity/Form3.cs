﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace activity
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            int classescounter = Form1.classescounter;
            string[,] aa = Form1.aa;
                DataTable table2 = new DataTable();
                table2.Columns.Add("L1".ToString());
                table2.Columns.Add("L2".ToString());
                table2.Columns.Add("L3".ToString());
                table2.Columns.Add("L4".ToString());
                table2.Columns.Add("L5".ToString());
                table2.Columns.Add("L6".ToString());
                table2.Columns.Add("L7".ToString());
                table2.Columns.Add("L8".ToString());
                table2.Columns.Add("L9".ToString());
                table2.Columns.Add("L10".ToString());
                table2.Columns.Add("L11".ToString());
                table2.Columns.Add("L12".ToString());
                table2.Columns.Add("L13".ToString());
                table2.Columns.Add("L14".ToString());
                table2.Columns.Add("L15".ToString());
                table2.Columns.Add("L16".ToString());
                table2.Columns.Add("L17".ToString());
                table2.Columns.Add("L18".ToString());
                table2.Columns.Add("L19".ToString());
                table2.Columns.Add("L20".ToString());
                table2.Columns.Add("L21".ToString());
                table2.Columns.Add("L22".ToString());
                table2.Columns.Add("L23".ToString());
                table2.Columns.Add("L24".ToString());
                table2.Columns.Add("L25".ToString());
                table2.Columns.Add("L26".ToString());
                table2.Columns.Add("L27".ToString());
                table2.Columns.Add("L28".ToString());
                table2.Columns.Add("L29".ToString());
                table2.Columns.Add("L30".ToString());
                table2.Columns.Add("L31".ToString());
                table2.Columns.Add("L32".ToString());
                table2.Columns.Add("L33".ToString());
                table2.Columns.Add("L34".ToString());
                table2.Columns.Add("L35".ToString());
                table2.Columns.Add("L36".ToString());
                table2.Columns.Add("L37".ToString());
                table2.Columns.Add("L38".ToString());
                table2.Columns.Add("L39".ToString());
                table2.Columns.Add("L40".ToString());
                
                for (int q = 0; q < classescounter; q++)
                {
                    DataRow dr = table2.NewRow();
                    for (int i = 0; i < 8; i++)
                    {
                        dr[i] = aa[q, i];
                    }
                    for(int i = 9; i < 17; i++)
                    {
                         dr[i-1] = aa[q, i];
                    }
                    for (int i = 18; i < 26; i++)
                    {
                        dr[i - 2] = aa[q, i];
                    }
                    for (int i = 27; i < 35; i++)
                    {
                        dr[i - 3] = aa[q, i];
                    }
                    for (int i = 36; i < 44; i++)
                    {
                        dr[i - 4] = aa[q, i - 2];
                    }

               
                         
                      
                    table2.Rows.Add(dr);
                }
                var bindingSource = new BindingSource();
                bindingSource.DataSource = table2;
                dataGridView1.DataSource = bindingSource;
                bindingSource.ResetBindings(true);
        }
    }
}
