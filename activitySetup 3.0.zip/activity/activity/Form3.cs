﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace activity
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {
            if (Form1.generatebtnclick == 1)
            {
                int classescounter = Form1.classescounter;

                string[,] aa = Form1.aa;
                DataTable table2 = new DataTable();
                table2.Columns.Add("Class Name".ToString());
                table2.Columns.Add("Day1 L1".ToString());
                table2.Columns.Add("Day1 L2".ToString());
                table2.Columns.Add("Day1 L3".ToString());
                table2.Columns.Add("Day1 L4".ToString());
                table2.Columns.Add("Day1 Break".ToString());
                table2.Columns.Add("Day1 L5".ToString());
                table2.Columns.Add("Day1 L6".ToString());
                table2.Columns.Add("Day1 L7".ToString());
                table2.Columns.Add("Day2 L1".ToString());
                table2.Columns.Add("Day2 L2".ToString());
                table2.Columns.Add("Day2 L3".ToString());
                table2.Columns.Add("Day2 L4".ToString());
                table2.Columns.Add("Day2 Break".ToString());
                table2.Columns.Add("Day2 L5".ToString());
                table2.Columns.Add("Day2 L6".ToString());
                table2.Columns.Add("Day2 L7".ToString());
                table2.Columns.Add("Day3 L1".ToString());
                table2.Columns.Add("Day3 L2".ToString());
                table2.Columns.Add("Day3 L3".ToString());
                table2.Columns.Add("Day3 L4".ToString());
                table2.Columns.Add("Day3 Break".ToString());
                table2.Columns.Add("Day3 L5".ToString());
                table2.Columns.Add("Day3 L6".ToString());
                table2.Columns.Add("Day3 L7".ToString());
                table2.Columns.Add("Day4 L1".ToString());
                table2.Columns.Add("Day4 L2".ToString());
                table2.Columns.Add("Day4 L3".ToString());
                table2.Columns.Add("Day4 L4".ToString());
                table2.Columns.Add("Day4 Break".ToString());
                table2.Columns.Add("Day4 L5".ToString());
                table2.Columns.Add("Day4 L6".ToString());
                table2.Columns.Add("Day4 L7".ToString());
                table2.Columns.Add("Day5 L1".ToString());
                table2.Columns.Add("Day5 L2".ToString());
                table2.Columns.Add("Day5 L3".ToString());
                table2.Columns.Add("Day5 L4".ToString());
                table2.Columns.Add("Day5 Break".ToString());
                table2.Columns.Add("Day5 L5".ToString());
                table2.Columns.Add("Day5 L6".ToString());
                table2.Columns.Add("Day5 L7".ToString());

                for (int q = 0; q < classescounter; q++)
                {
                    DataRow dr = table2.NewRow();
                    dr[0] = Form1.classes[q];
                    for (int i = 0; i < 8; i++)
                    {
                        dr[i+1] = aa[q, i];
                    }
                    for (int i = 9; i < 17; i++)
                    {
                        dr[i] = aa[q, i];
                    }
                    for (int i = 18; i < 26; i++)
                    {
                        dr[i - 1] = aa[q, i];
                    }
                    for (int i = 27; i < 35; i++)
                    {
                        dr[i - 2] = aa[q, i];
                    }
                    for (int i = 36; i < 44; i++)
                    {
                        dr[i - 3] = aa[q, i];
                    }
                    table2.Rows.Add(dr);
                }
                var bindingSource = new BindingSource();
                bindingSource.DataSource = table2;
                dataGridView1.DataSource = bindingSource;
                bindingSource.ResetBindings(true);
            }
            else
            {
                MessageBox.Show("You have not generated time table");
            }
            
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
