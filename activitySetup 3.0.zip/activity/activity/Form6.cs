﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace activity
{
    public partial class Form6 : Form
    {
        public Form6()
        {
            InitializeComponent();
            
        }

        public void addfunction(string[][,] cd1 , int classescounter,int[] classCourse,int classIndex)
        {
            int teacherNameLength = textBox1.Text.Length;
            int subjectNameLength = textBox3.Text.Length;
            if (teacherNameLength < 50 && subjectNameLength < 50)
            {
                int tid;
                bool parsesuccess = int.TryParse(textBox2.Text, out tid);
                if (textBox1.Text != null && textBox3.Text != null)
                {
                    if (parsesuccess)
                    {
                        if (Convert.ToInt32(textBox2.Text) >= 0 && Convert.ToInt32(textBox2.Text) < 50)
                        {
                            bool teacherNumberCheck = true;
                            for (int i = 0; i < classescounter; i++)
                            {
                                for (int j = 0; j < classCourse[i]; j++)
                                {
                                    if (textBox2.Text == cd1[i][j, 1])
                                    {
                                        if (textBox1.Text!=cd1[i][j,0])
                                        {
                                            teacherNumberCheck = true;
                                            break;
                                        }
                                        
                                    }
                                }
                            }
                            int totalClassWorkingHour = 0;
                            for (int j = 0; j < classCourse[classIndex]; j++)
                            {

                                totalClassWorkingHour += Convert.ToInt32(cd1[classIndex][j, 3]);

                            }

                            if (!teacherNumberCheck)
                            {
                                MessageBox.Show("Entered Teacher id is already assigned to a teacher");
                            }
                            else
                            {
                                if (totalClassWorkingHour < 34 && classCourse[classIndex] < 10)
                                {
                                    Form1.cd1[classIndex][classCourse[classIndex], 0] = textBox1.Text;
                                    Form1.cd1[classIndex][classCourse[classIndex], 1] = textBox2.Text;
                                    Form1.cd1[classIndex][classCourse[classIndex], 2] = textBox3.Text;
                                    Form1.cd1[classIndex][classCourse[classIndex], 3] = textBox4.Text;
                                    Form1.cd1[classIndex][classCourse[classIndex], 4] = textBox5.Text;
                                    Form1.classCourse[classIndex] = classCourse[classIndex] + 1;
                                    MessageBox.Show("Details have been added successfully");
                                    textBox1.Clear();
                                    textBox2.Clear();
                                    textBox3.Clear();
                                    textBox4.Text = "Select";
                                    textBox5.Text = "Select";
                                    Form1.courseCheck = 1;
                                }
                                else
                                {
                                    MessageBox.Show("Working Hour limit(33) has been reached for this class or\nClass course limit(10) has been reached.");
                                }

                            }

                        }
                        else
                        {
                            MessageBox.Show("Teacher Id must be between 0 to 49");
                        }

                    }
                    else
                    {
                        MessageBox.Show("Teacher id must be in digits");
                    }
                }
                else
                {
                    MessageBox.Show("Teacher and subject name must be string");
                }
            }
            else
            {
                MessageBox.Show("Teacher name or subject name length\ncannot be greater than 50");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
           // addfunction(Form1.cd1,Form1.classescounter,Form1.classCourse,Form1.classIndex);
        }

        private void show_detail_Click(object sender, EventArgs e)
        {
           // Form1.button8.Visible = true;
            Form2 f2 = new Form2();
            f2.TopLevel = false;
            f2.FormBorderStyle = FormBorderStyle.None;
            f2.Dock = DockStyle.Fill;
            Controls.Add(f2);
           // panel4.Tag = f2;
            f2.BringToFront();

            f2.Show();
            Form1.currentchildform = f2;
          //  button2.Visible = true;
            
        }

      

        private void show_detail_Click_1(object sender, EventArgs e)
        {
            Form2 f2 = new Form2();
            f2.TopLevel = false;
            f2.FormBorderStyle = FormBorderStyle.None;
            f2.Dock = DockStyle.Fill;
            panel2.Controls.Add(f2);
            // panel4.Tag = f2;
            f2.BringToFront();
            f2.Show();
          //  button2.Visible = true;
            Form6 f6 = new Form6();
            if (Form1.currentchildform.Text != "Form6")
            {
                MessageBox.Show(f6.Text);
                Form1.currentchildform.Close();
            }
            Form1.currentchildform = f2;
            
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            if (Form1.classescounter > 0)
            {
                if(textBox4.SelectedIndex !=-1 && textBox5.SelectedIndex != -1)
                {
                    int totalcd = 0;
                    for(int i = 0; i < Form1.classCourse[Form1.classIndex]; i++)
                    {
                        totalcd += Convert.ToInt32(Form1.cd1[Form1.classIndex][i, 3]);
                    }
                    totalcd += Convert.ToInt32(textBox4.Text);
                    if (totalcd < 34)
                    {
                      //  MessageBox.Show(Convert.ToString(totalcd));
                        addfunction(Form1.cd1, Form1.classescounter, Form1.classCourse, Form1.classIndex);
                    }
                    else
                    {
                        MessageBox.Show("You can maximum 33 cd to a class and\nthe limit for this class has been reached");
                    }
                    
                }
                else
                {
                    MessageBox.Show("You have not selected Consecutive option\nor credit hour option");
                }
                
            }
            else
            {
                MessageBox.Show("You have not added any class yet");
            }
        }

        private void textBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (textBox5.Text == "1")
            {
                textBox4.Items.Clear();
                for (int i = 1; i <= 3; i++)
                {
                    textBox4.Items.Add(Convert.ToString(i));
                }
            }
            if (textBox5.Text == "0")
            {
                textBox4.Items.Clear();
                for (int i = 1; i <= 10; i++)
                {
                    textBox4.Items.Add(Convert.ToString(i));
                }
            }
        }
    }
}
