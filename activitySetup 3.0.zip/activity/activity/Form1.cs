﻿using System;
using System.CodeDom.Compiler;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace activity
{
    public partial class Form1 : Form
    {
        public static Form currentchildform;
        public Form1()
        {
            InitializeComponent();
            label2.Text = note;
            button6.Enabled = false;
            button2.Enabled = false;
            button4.Enabled = false;
            button5.Enabled = false;
            button3.Enabled = false;
            textBox6.Enabled = false;
            if (classescounter == 0)
            {
                dataGridView2.Visible = false;
                
            }
        }
        public static string[][,] cd1 = new string[12][,] {
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5],
                new string[10,5]
         };

        public static int[] classCourse = new int[12] { 0, 0, 0, 0, 0,0,0,0,0,0,0,0 };
        public static string[] classes = new string[12];
        public static string[,] aa;
        public static int[] asd = { 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 1, 1, 1, 0, 1, 1, 1, 1, 0, 0, 1, 1, 0 };
        public static int classescounter = 0;
         public static int classIndex = 0;
        public static int generatebtnclick = 0;
        public static int courseCheck=0;

        string note = "Press the below button to UNLOCK project";
        
        public void populate(string[] classes)
        {
            DataTable table = new DataTable();
            table.Columns.Add("Classes".ToString());
            
            for (int i = 0; i < classescounter;i++){
                DataRow dr = table.NewRow();
                dr["Classes"] = classes[i];                        
                table.Rows.Add(dr);
            }
            
            var bindingSource = new BindingSource();
            bindingSource.DataSource = table;
            dataGridView2.DataSource = bindingSource;
            bindingSource.ResetBindings(true);


        }

       
       
        private void button3_Click(object sender, EventArgs e)
        {
            
            string classcheck= textBox6.Text;
            int classNameLength = textBox6.Text.Length;
            if (classescounter < 12)
            {
                if (classcheck != "" && classNameLength<50)
                {
                    classes[classescounter] = classcheck;
                    classescounter++;
                    dataGridView2.Visible = true;
                    textBox6.Clear();
                    populate(classes);
                }
                else
                {
                    MessageBox.Show("you have not added any class name");
                }
            }
            else
            {
                MessageBox.Show("You can add maximum 12 Classes");
            }
            
            
        }

        private void button2_Click(object sender, EventArgs e)
        {
          
            Form4 f4 = new Form4();
            f4.TopLevel = false;
            f4.FormBorderStyle = FormBorderStyle.None;
            f4.Dock = DockStyle.Fill;
            panel4.Controls.Add(f4);
            panel4.Tag = f4;
            f4.BringToFront();
            f4.Show();
            currentchildform = f4;
        }

        private void button4_Click(object sender, EventArgs e)
        {
           
            Form3 f3 = new Form3();
            f3.TopLevel = false;
            f3.FormBorderStyle = FormBorderStyle.None;
            f3.Dock = DockStyle.Fill;
            panel4.Controls.Add(f3);
            panel4.Tag = f3;
            f3.BringToFront();
            f3.Show();
            currentchildform = f3;
        }

       

        private void dataGridView2_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            classIndex = e.RowIndex;
            if (currentchildform.Text != "Form6")
            {
                Form6 f6 = new Form6();
                f6.TopLevel = false;
                f6.FormBorderStyle = FormBorderStyle.None;
                f6.Dock = DockStyle.Fill;
                panel4.Controls.Add(f6);
                panel4.Tag = f6;
                f6.BringToFront();
                f6.Show();
                currentchildform = f6;
            }
         
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.TopLevel = false;
            f6.FormBorderStyle = FormBorderStyle.None;
            f6.Dock = DockStyle.Fill;
            panel4.Controls.Add(f6);
            panel4.Tag = f6;
            f6.BringToFront();
            f6.Show();
            currentchildform = f6;

        }

        private void button7_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button5_Click(object sender, EventArgs e)
        {
           
            Form5 f5 = new Form5();
            f5.TopLevel = false;
            f5.FormBorderStyle = FormBorderStyle.None;
            f5.Dock = DockStyle.Fill;
            panel4.Controls.Add(f5);
            panel4.Tag = f5;
            f5.BringToFront();
            f5.Show();
            currentchildform = f5;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form6 f6 = new Form6();
            f6.TopLevel = false;
            f6.FormBorderStyle = FormBorderStyle.None;
            f6.Dock = DockStyle.Fill;
            panel4.Controls.Add(f6);
            panel4.Tag = f6;
            f6.BringToFront();
            f6.Show();
            currentchildform = f6;
            
            button6.Enabled = true;
            button2.Enabled = true;
            button4.Enabled = true;
            button5.Enabled = true;
            button3.Enabled = true;
            textBox6.Enabled = true;

        }
    }
}
