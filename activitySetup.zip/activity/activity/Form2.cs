﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace activity
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            int[] classCourse = Form1.classCourse;
            int classIndex = Form1.classIndex;
            string[][,] cd1 = Form1.cd1;
          //  private void populateClass(string[][,] cd1, int classIndex)
           // {
                DataTable table1 = new DataTable();
                table1.Columns.Add("Teacher".ToString());
                table1.Columns.Add("Subject".ToString());
                table1.Columns.Add("Credit Hour".ToString());
                for (int i = 0; i < classCourse[classIndex]; i++)
                {
                    // MessageBox.Show(Convert.ToString(cd1[classIndex][0, 2]));
                    DataRow dr = table1.NewRow();
                    dr["Teacher"] = cd1[classIndex][i, 0];
                    dr["Subject"] = cd1[classIndex][i, 2];
                    dr["Credit Hour"] = cd1[classIndex][i, 3];
                    table1.Rows.Add(dr);
                }
                var bindingSource = new BindingSource();
                bindingSource.DataSource = table1;
                dataGridView1.DataSource = bindingSource;
                bindingSource.ResetBindings(true);
          //  }
        }
    }
}
