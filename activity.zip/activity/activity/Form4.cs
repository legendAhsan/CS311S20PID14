﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace activity
{
    public partial class Form4 : Form
    {
        public Form4()
        {
            InitializeComponent();
        }


        static string[,] Time_Table_Generator1(string[][,] Class_Details, int[] Available_Slots, int classescounter, int[] classCourse)
        {
            // string [,] Final_Time_Table;
            string[,] Final_Time_Table = new string[12, 45];
            string[,] Teachers = new string[50, 45];                                //value need to be specify
            int[] Class_Available_Slots = new int[Available_Slots.Length];


            for (int q = 0; q < 50; q++)
                for (int w = 0; w < 45; w++)
                    Teachers[q, w] = "None";
            int Total_Credit_Hours = 0;
            int Teacher_No;
            bool Allow;
            for (int clas = 0; clas < classescounter/*Class_Details.GetLength(0)*/; clas++)
            {
                // Class_Available_Slots = Available_Slots;
                for (int g = 0; g < Available_Slots.Length; g++)
                {
                    Class_Available_Slots[g] = Available_Slots[g];
                }
                Total_Credit_Hours = 0;
                //Console.WriteLine("end1fgfgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
                int Lecture_NO = 0;

                for (int i = 0; i < classCourse[clas];/* Class_Details[clas].GetLength(0);*/ i++)
                {
                    //  MessageBox.Show[Convert.ToString(Class_Details[clas].GetLength(0))];
                    Total_Credit_Hours += int.Parse(Class_Details[clas][i, 3]);
                    //    Console.WriteLine(int.Parse(Class_Details[clas, i, 4]));
                }
                while (Total_Credit_Hours >= 1)
                {
                    //Console.WriteLine(Total_Credit_Hours);
                    //Console.WriteLine("end1");
                    for (int teach = 0; teach < classCourse[clas];/* Class_Details[clas].GetLength(0);*/ teach++)
                    {

                        if (Lecture_NO == 45)
                        {
                            Lecture_NO = 0;
                        }

                        Teacher_No = int.Parse(Class_Details[clas][teach, 1]);
                        //  Console.WriteLine("end2");
                        if ((Class_Available_Slots[Lecture_NO] == 0 || (Teachers[Teacher_No, Lecture_NO] != "None") && (Lecture_NO < Class_Available_Slots.Length - 1)))
                        {
                            Lecture_NO++;
                            teach--;
                            continue;
                            //    Console.WriteLine("end222");
                        }




                        if (((Teachers[Teacher_No, Lecture_NO] == "None")) && (int.Parse(Class_Details[clas][teach, 3]) != 0) && (int.Parse(Class_Details[clas][teach, 4]) == 0))
                        {
                            //     Console.WriteLine("end222");
                            Final_Time_Table[clas, Lecture_NO] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                            Teachers[Teacher_No, Lecture_NO] = clas.ToString() + "---" + Class_Details[clas][teach, 2];          // ln kya hai
                            int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                            Class_Details[clas][teach, 3] = t.ToString();
                            Total_Credit_Hours--;
                            Class_Available_Slots[Lecture_NO] = 0;
                            if (Lecture_NO < Class_Available_Slots.Length - 1)
                            {
                                Lecture_NO++;
                            }
                            else
                            {
                                Lecture_NO = 0;
                            }

                        }
                        else if (int.Parse(Class_Details[clas][teach, 4]) == 1 && int.Parse(Class_Details[clas][teach, 3]) != 0)
                        {
                            //  Console.WriteLine("end222");
                            Allow = true;
                            if ((Lecture_NO + int.Parse(Class_Details[clas][teach, 3]) < Class_Available_Slots.Length))
                            {
                                for (int i = Lecture_NO; i < (Lecture_NO + int.Parse(Class_Details[clas][teach, 3])); i++)
                                {

                                    if ((Teachers[Teacher_No, i] != "None") || (Class_Available_Slots[i] != 1))
                                    {
                                        Allow = false;
                                        // Console.WriteLine("endeeeeeeeeeeeeeeeeeeeeeeee211122");
                                        break;
                                    }
                                }

                            }
                            else
                            {
                                Allow = false;
                            }
                            if (Allow)
                            {
                                for (int i = Lecture_NO; i < (Lecture_NO + int.Parse(Class_Details[clas][teach, 3])); i++)
                                {
                                    Final_Time_Table[clas, i] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                    Teachers[Teacher_No, i] = clas + "---" + Class_Details[clas][teach, 2];
                                    int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                    Class_Details[clas][teach, 3] = t.ToString();
                                    //  Console.WriteLine("end211122");
                                    Total_Credit_Hours--;
                                    Class_Available_Slots[Lecture_NO] = 0;
                                    if (Lecture_NO < Class_Available_Slots.Length - 1)
                                    {
                                        Lecture_NO++;
                                    }
                                    else
                                    {
                                        Lecture_NO = 0;
                                    }

                                }
                            }
                        }
                    }
                    //
                }
            }
            //   Console.WriteLine("end");
            return Final_Time_Table;
        }

        static string[,] Minimum_Room_Allocator1(string[,] Final_Time_Table)
        {
            int m;
            for (int q = 0; q < Final_Time_Table.GetLength(0); q++)
                for (int w = 0; w < Final_Time_Table.GetLength(1); w++)
                {
                    Final_Time_Table[q, w] += "//";
                }

            for (int Room_No = 0; Room_No < Final_Time_Table.GetLength(0); Room_No++)
            {
                for (int lecture_No = 0; lecture_No < Final_Time_Table.GetLength(1); lecture_No++)
                {
                    for (int i = Room_No; i < Final_Time_Table.GetLength(0); i++)
                    {
                        if (lecture_No == 0)
                        {
                            if (!(Final_Time_Table[i, lecture_No].Contains("R. No . ")) && Final_Time_Table[i, lecture_No] != "//")
                            {
                                for (int j = lecture_No; j < Final_Time_Table.GetLength(1); j++)
                                {
                                    Final_Time_Table[i, j] += "R. No . " + Room_No;
                                    m = j + 1;
                                    if (m == Final_Time_Table.GetLength(1))
                                    {
                                        break;
                                    }
                                    if (Final_Time_Table[i, j] != Final_Time_Table[i, m])
                                    {
                                        break;
                                    }
                                }
                                break;
                            }
                        }
                        else
                        {
                            if (!(Final_Time_Table[i, lecture_No].Contains("R. No . ")) && Final_Time_Table[i, lecture_No] != "//" && Final_Time_Table[i, lecture_No - 1] != Final_Time_Table[i, lecture_No])
                            {
                                for (int j = lecture_No; j < Final_Time_Table.GetLength(1); j++)
                                {
                                    Final_Time_Table[i, j] += "R. No . " + Room_No;
                                    m = j + 1;
                                    if (m == Final_Time_Table.GetLength(1))
                                    {
                                        break;
                                    }
                                    if (Final_Time_Table[i, j] != Final_Time_Table[i, m])
                                    {
                                        break;
                                    }
                                }
                                break;
                            }
                        }

                    }
                }
            }
            return Final_Time_Table;
        }



        // mark 2
        static string[,] Time_Table_Generator2(string[][,] Class_Details, int[] Available_Slots, int classescounter, int[] classCourse)
        {
            // string [,] Final_Time_Table;
            string[,] Final_Time_Table = new string[12, 45];
            string[,] Teachers = new string[50, 45];                                //value need to be specify
            int[] Class_Available_Slots = new int[Available_Slots.Length];


            for (int q = 0; q < 50; q++)
                for (int w = 0; w < 45; w++)
                    Teachers[q, w] = "None";
            int Total_Credit_Hours = 0;
            int Teacher_No;
            bool Allow;
            for (int clas = 0; clas < classescounter/*Class_Details.GetLength(0)*/; clas++)
            {
                if (clas % 2 == 0)
                {
                    // Class_Available_Slots = Available_Slots;
                    for (int g = 0; g < Available_Slots.Length; g++)
                    {
                        Class_Available_Slots[g] = Available_Slots[g];
                    }
                    Total_Credit_Hours = 0;
                    //Console.WriteLine("end1fgfgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
                    int Lecture_NO = 0;

                    for (int i = 0; i < classCourse[clas]; /*Class_Details[clas].GetLength(0);*/ i++)
                    {
                        Total_Credit_Hours += int.Parse(Class_Details[clas][i, 3]);
                        //    Console.WriteLine(int.Parse(Class_Details[clas, i, 4]));
                    }
                    while (Total_Credit_Hours >= 1)
                    {
                        //Console.WriteLine(Total_Credit_Hours);
                        //Console.WriteLine("end1");
                        for (int teach = 0; teach < classCourse[clas]; /*Class_Details[clas].GetLength(0);*/ teach++)
                        {

                            if (Lecture_NO == 45)
                            {
                                Lecture_NO = 0;
                            }

                            Teacher_No = int.Parse(Class_Details[clas][teach, 1]);
                            //  Console.WriteLine("end2");
                            if ((Class_Available_Slots[Lecture_NO] == 0 || (Teachers[Teacher_No, Lecture_NO] != "None") && (Lecture_NO < Class_Available_Slots.Length - 1)))
                            {
                                Lecture_NO++;
                                teach--;
                                continue;
                                //    Console.WriteLine("end222");
                            }




                            if (((Teachers[Teacher_No, Lecture_NO] == "None")) && (int.Parse(Class_Details[clas][teach, 3]) != 0) && (int.Parse(Class_Details[clas][teach, 4]) == 0))
                            {
                                //     Console.WriteLine("end222");
                                Final_Time_Table[clas, Lecture_NO] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                Teachers[Teacher_No, Lecture_NO] = clas.ToString() + "---" + Class_Details[clas][teach, 2];          // ln kya hai
                                int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                Class_Details[clas][teach, 3] = t.ToString();
                                Total_Credit_Hours--;
                                Class_Available_Slots[Lecture_NO] = 0;
                                if (Lecture_NO < Class_Available_Slots.Length - 1)
                                {
                                    Lecture_NO++;
                                }
                                else
                                {
                                    Lecture_NO = 0;
                                }

                            }
                            else if (int.Parse(Class_Details[clas][teach, 4]) == 1 && int.Parse(Class_Details[clas][teach, 3]) != 0)
                            {
                                //  Console.WriteLine("end222");
                                Allow = true;
                                if ((Lecture_NO + int.Parse(Class_Details[clas][teach, 3]) < Class_Available_Slots.Length))
                                {
                                    for (int i = Lecture_NO; i < (Lecture_NO + int.Parse(Class_Details[clas][teach, 3])); i++)
                                    {

                                        if ((Teachers[Teacher_No, i] != "None") || (Class_Available_Slots[i] != 1))
                                        {
                                            Allow = false;
                                            // Console.WriteLine("endeeeeeeeeeeeeeeeeeeeeeeee211122");
                                            break;
                                        }
                                    }

                                }
                                else
                                {
                                    Allow = false;
                                }
                                if (Allow)
                                {
                                    for (int i = Lecture_NO; i < (Lecture_NO + int.Parse(Class_Details[clas][teach, 3])); i++)
                                    {
                                        Final_Time_Table[clas, i] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                        Teachers[Teacher_No, i] = clas + "---" + Class_Details[clas][teach, 2];
                                        int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                        Class_Details[clas][teach, 3] = t.ToString();
                                        //  Console.WriteLine("end211122");
                                        Total_Credit_Hours--;
                                        Class_Available_Slots[Lecture_NO] = 0;
                                        if (Lecture_NO < Class_Available_Slots.Length - 1)
                                        {
                                            Lecture_NO++;
                                        }
                                        else
                                        {
                                            Lecture_NO = 0;
                                        }

                                    }
                                }
                            }
                        }
                        //
                    }

                }
                else
                {
                    // Class_Available_Slots = Available_Slots;
                    for (int g = 0; g < Available_Slots.Length; g++)
                    {
                        Class_Available_Slots[g] = Available_Slots[g];
                    }
                    Total_Credit_Hours = 0;
                    //Console.WriteLine("end1fgfgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
                    int Lecture_NO = Class_Available_Slots.Length - 1;

                    for (int i = 0; i < classCourse[clas]; /*Class_Details[clas].GetLength(0);*/ i++)
                    {
                        Total_Credit_Hours += int.Parse(Class_Details[clas][i, 3]);
                        //    Console.WriteLine(int.Parse(Class_Details[clas, i, 4]));
                    }
                    while (Total_Credit_Hours >= 1)
                    {
                        //Console.WriteLine(Total_Credit_Hours);
                        //Console.WriteLine("end1");
                        for (int teach = 0; teach < classCourse[clas]; /*Class_Details[clas].GetLength(0);*/ teach++)
                        {

                            if (Lecture_NO == -1)
                            {
                                Lecture_NO = Class_Available_Slots.Length - 1;
                            }

                            Teacher_No = int.Parse(Class_Details[clas][teach, 1]);
                            //  Console.WriteLine("end2");
                            if ((Class_Available_Slots[Lecture_NO] == 0 || (Teachers[Teacher_No, Lecture_NO] != "None") && (Lecture_NO >= 1)))
                            {
                                Lecture_NO--;
                                teach--;
                                continue;
                                //    Console.WriteLine("end222");
                            }




                            if (((Teachers[Teacher_No, Lecture_NO] == "None")) && (int.Parse(Class_Details[clas][teach, 3]) != 0) && (int.Parse(Class_Details[clas][teach, 4]) == 0))
                            {
                                //     Console.WriteLine("end222");
                                Final_Time_Table[clas, Lecture_NO] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                Teachers[Teacher_No, Lecture_NO] = clas.ToString() + "---" + Class_Details[clas][teach, 2];          // ln kya hai
                                int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                Class_Details[clas][teach, 3] = t.ToString();
                                Total_Credit_Hours--;
                                Class_Available_Slots[Lecture_NO] = 0;
                                if (Lecture_NO >= 1)
                                {
                                    Lecture_NO--;
                                }
                                else
                                {
                                    Lecture_NO = Class_Available_Slots.Length - 1;
                                }

                            }
                            else if (int.Parse(Class_Details[clas][teach, 4]) == 1 && int.Parse(Class_Details[clas][teach, 3]) != 0)
                            {
                                //  Console.WriteLine("end222");
                                Allow = true;
                                if ((Lecture_NO - int.Parse(Class_Details[clas][teach, 3]) >= -1))
                                {
                                    for (int i = Lecture_NO; i > (Lecture_NO - int.Parse(Class_Details[clas][teach, 3])); i--)
                                    {

                                        if ((Teachers[Teacher_No, i] != "None") || (Class_Available_Slots[i] != 1))
                                        {
                                            Allow = false;
                                            // Console.WriteLine("endeeeeeeeeeeeeeeeeeeeeeeee211122");
                                            break;
                                        }
                                    }

                                }
                                else
                                {
                                    Allow = false;
                                }
                                if (Allow)
                                {
                                    for (int i = Lecture_NO; i > (Lecture_NO - int.Parse(Class_Details[clas][teach, 3])); i--)
                                    {
                                        Final_Time_Table[clas, i] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                        Teachers[Teacher_No, i] = clas + "---" + Class_Details[clas][teach, 2];
                                        int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                        Class_Details[clas][teach, 3] = t.ToString();
                                        //  Console.WriteLine("end211122");
                                        Total_Credit_Hours--;
                                        Class_Available_Slots[Lecture_NO] = 0;
                                        if (Lecture_NO >= 1)
                                        {
                                            Lecture_NO--;
                                        }
                                        else
                                        {
                                            Lecture_NO = Class_Available_Slots.Length;
                                        }

                                    }
                                }
                            }
                        }
                        //
                    }

                }

            }
            //   Console.WriteLine("end");
            return Final_Time_Table;
        }
        

        // mark3
        static string[,] Time_Table_Generator3(string[][,] Class_Details, int[] Available_Slots, int classescounter,int[] classCourse)
        {
            // string [,] Final_Time_Table;
            Random rnd = new Random();
            string[,] Final_Time_Table = new string[12, 45];
            string[,] Teachers = new string[50, 45];                                //value need to be specify
            int[] Class_Available_Slots = new int[Available_Slots.Length];


            for (int q = 0; q < 50; q++)
                for (int w = 0; w < 45; w++)
                    Teachers[q, w] = "None";
            int Total_Credit_Hours = 0;
            int TCH = 0;
            int Teacher_No;
            bool Allow;
            for (int clas = 0; clas < classescounter;/* Class_Details.GetLength(0);*/ clas++)
            {
                if (clas <= (classescounter) / 2)
                {
                    // Class_Available_Slots = Available_Slots;
                    for (int g = 0; g < Available_Slots.Length; g++)
                    {
                        Class_Available_Slots[g] = Available_Slots[g];
                    }
                    Total_Credit_Hours = 0;
                    //Console.WriteLine("end1fgfgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
                    int Lecture_NO = 0;

                    for (int i = 0; i < classCourse[clas]; /* Class_Details[clas].GetLength(0);*/ i++)
                    {
                        Total_Credit_Hours += int.Parse(Class_Details[clas][i, 3]);
                        //    Console.WriteLine(int.Parse(Class_Details[clas, i, 4]));
                    }
                    TCH = Total_Credit_Hours;
                    while (Total_Credit_Hours >= 1)
                    {
                        //Console.WriteLine(Total_Credit_Hours);
                        //Console.WriteLine("end1");
                        for (int teach = 0; teach < classCourse[clas]; /*Class_Details[clas].GetLength(0);*/ teach++)
                        {

                            if (rnd.Next(1, 100) < (99 - TCH))
                            {
                                Lecture_NO++;
                            }

                            if (Lecture_NO >= 45)
                            {
                                Lecture_NO = 0;
                            }

                            Teacher_No = int.Parse(Class_Details[clas][teach, 1]);
                            //  Console.WriteLine("end2");
                            if ((Class_Available_Slots[Lecture_NO] == 0 || (Teachers[Teacher_No, Lecture_NO] != "None") && (Lecture_NO < Class_Available_Slots.Length - 1)))
                            {
                                Lecture_NO++;
                                teach--;
                                continue;
                                //    Console.WriteLine("end222");
                            }




                            if (((Teachers[Teacher_No, Lecture_NO] == "None")) && (int.Parse(Class_Details[clas][teach, 3]) != 0) && (int.Parse(Class_Details[clas][teach, 4]) == 0))
                            {
                                //     Console.WriteLine("end222");
                                Final_Time_Table[clas, Lecture_NO] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                Teachers[Teacher_No, Lecture_NO] = clas.ToString() + "---" + Class_Details[clas][teach, 2];          // ln kya hai
                                int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                Class_Details[clas][teach, 3] = t.ToString();
                                Total_Credit_Hours--;
                                Class_Available_Slots[Lecture_NO] = 0;
                                if (Lecture_NO < Class_Available_Slots.Length - 1)
                                {
                                    Lecture_NO++;
                                }
                                else
                                {
                                    Lecture_NO = 0;
                                }

                            }
                            else if (int.Parse(Class_Details[clas][teach, 4]) == 1 && int.Parse(Class_Details[clas][teach, 3]) != 0)
                            {
                                //  Console.WriteLine("end222");
                                Allow = true;
                                if ((Lecture_NO + int.Parse(Class_Details[clas][teach, 3]) < Class_Available_Slots.Length))
                                {
                                    for (int i = Lecture_NO; i < (Lecture_NO + int.Parse(Class_Details[clas][teach, 3])); i++)
                                    {

                                        if ((Teachers[Teacher_No, i] != "None") || (Class_Available_Slots[i] != 1))
                                        {
                                            Allow = false;
                                            // Console.WriteLine("endeeeeeeeeeeeeeeeeeeeeeeee211122");
                                            break;
                                        }
                                    }

                                }
                                else
                                {
                                    Allow = false;
                                }
                                if (Allow)
                                {
                                    for (int i = Lecture_NO; i < (Lecture_NO + int.Parse(Class_Details[clas][teach, 3])); i++)
                                    {
                                        Final_Time_Table[clas, i] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                        Teachers[Teacher_No, i] = clas + "---" + Class_Details[clas][teach, 2];
                                        int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                        Class_Details[clas][teach, 3] = t.ToString();
                                        //  Console.WriteLine("end211122");
                                        Total_Credit_Hours--;
                                        Class_Available_Slots[Lecture_NO] = 0;
                                        if (Lecture_NO < Class_Available_Slots.Length - 1)
                                        {
                                            Lecture_NO++;
                                        }
                                        else
                                        {
                                            Lecture_NO = 0;
                                        }

                                    }
                                }
                            }
                        }
                        //
                    }

                }
                else
                {
                    // Class_Available_Slots = Available_Slots;
                    for (int g = 0; g < Available_Slots.Length; g++)
                    {
                        Class_Available_Slots[g] = Available_Slots[g];
                    }
                    Total_Credit_Hours = 0;
                    //Console.WriteLine("end1fgfgggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggggg");
                    int Lecture_NO = Class_Available_Slots.Length - 1;

                    for (int i = 0; i < classCourse[clas]; /*Class_Details[clas].GetLength(0);*/ i++)
                    {
                        Total_Credit_Hours += int.Parse(Class_Details[clas][i, 3]);
                        //    Console.WriteLine(int.Parse(Class_Details[clas, i, 4]));
                    }
                    TCH = Total_Credit_Hours;
                    while (Total_Credit_Hours >= 1)
                    {
                        //Console.WriteLine(Total_Credit_Hours);
                        //Console.WriteLine("end1");
                        for (int teach = 0; teach < classCourse[clas]; /*Class_Details[clas].GetLength(0);*/ teach++)
                        {
                            if (rnd.Next(1, 100) < (99 - TCH))
                            {
                                Lecture_NO--;
                            }
                            if (Lecture_NO <= -1)
                            {
                                Lecture_NO = Class_Available_Slots.Length - 1;
                            }

                            Teacher_No = int.Parse(Class_Details[clas][teach, 1]);
                            //  Console.WriteLine("end2");
                            if ((Class_Available_Slots[Lecture_NO] == 0 || (Teachers[Teacher_No, Lecture_NO] != "None") && (Lecture_NO >= 1)))
                            {
                                Lecture_NO--;
                                teach--;
                                continue;
                                //    Console.WriteLine("end222");
                            }




                            if (((Teachers[Teacher_No, Lecture_NO] == "None")) && (int.Parse(Class_Details[clas][teach, 3]) != 0) && (int.Parse(Class_Details[clas][teach, 4]) == 0))
                            {
                                //     Console.WriteLine("end222");
                                Final_Time_Table[clas, Lecture_NO] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                Teachers[Teacher_No, Lecture_NO] = clas.ToString() + "---" + Class_Details[clas][teach, 2];          // ln kya hai
                                int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                Class_Details[clas][teach, 3] = t.ToString();
                                Total_Credit_Hours--;
                                Class_Available_Slots[Lecture_NO] = 0;
                                if (Lecture_NO >= 1)
                                {
                                    Lecture_NO--;
                                }
                                else
                                {
                                    Lecture_NO = Class_Available_Slots.Length - 1;
                                }

                            }
                            else if (int.Parse(Class_Details[clas][teach, 4]) == 1 && int.Parse(Class_Details[clas][teach, 3]) != 0)
                            {
                                //  Console.WriteLine("end222");
                                Allow = true;
                                if ((Lecture_NO - int.Parse(Class_Details[clas][teach, 3]) >= -1))
                                {
                                    for (int i = Lecture_NO; i > (Lecture_NO - int.Parse(Class_Details[clas][teach, 3])); i--)
                                    {

                                        if ((Teachers[Teacher_No, i] != "None") || (Class_Available_Slots[i] != 1))
                                        {
                                            Allow = false;
                                            // Console.WriteLine("endeeeeeeeeeeeeeeeeeeeeeeee211122");
                                            break;
                                        }
                                    }

                                }
                                else
                                {
                                    Allow = false;
                                }
                                if (Allow)
                                {
                                    for (int i = Lecture_NO; i > (Lecture_NO - int.Parse(Class_Details[clas][teach, 3])); i--)
                                    {
                                        Final_Time_Table[clas, i] = Class_Details[clas][teach, 0] + "," + Class_Details[clas][teach, 2];
                                        Teachers[Teacher_No, i] = clas + "---" + Class_Details[clas][teach, 2];
                                        int t = int.Parse(Class_Details[clas][teach, 3]) - 1;
                                        Class_Details[clas][teach, 3] = t.ToString();
                                        //  Console.WriteLine("end211122");
                                        Total_Credit_Hours--;
                                        Class_Available_Slots[Lecture_NO] = 0;
                                        if (Lecture_NO >= 1)
                                        {
                                            Lecture_NO--;
                                        }
                                        else
                                        {
                                            Lecture_NO = Class_Available_Slots.Length;
                                        }

                                    }
                                }
                            }
                        }
                        //
                    }

                }

            }
            //   Console.WriteLine("end");
            return Final_Time_Table;
        }
        

        private void button1_Click(object sender, EventArgs e)
        {
            switch (comboBox1.Text)
            {
                case "Mark1":
                    Form1.aa = Time_Table_Generator1(Form1.cd1, Form1.asd,Form1.classescounter,Form1.classCourse);
                    Form1.aa = Minimum_Room_Allocator1(Form1.aa);
                    break;
                case "Mark2":
                    Form1.aa = Time_Table_Generator2(Form1.cd1, Form1.asd, Form1.classescounter, Form1.classCourse);
                    Form1.aa = Minimum_Room_Allocator1(Form1.aa);
                    break;
                case "Mark3":
                    Form1.aa = Time_Table_Generator3(Form1.cd1, Form1.asd, Form1.classescounter, Form1.classCourse);
                    Form1.aa = Minimum_Room_Allocator1(Form1.aa);
                    break;


            }
            MessageBox.Show("Time Table Generated");
        }

        private void Form4_Load(object sender, EventArgs e)
        {
           // string[,] aa = Form1.aa;
        }
    }
}
